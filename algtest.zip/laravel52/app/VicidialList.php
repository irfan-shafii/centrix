<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class VicidialList extends Model
{
	protected $connection = 'mysql2';
    protected  $table="vicidial_list";
}
