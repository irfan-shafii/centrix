<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class VicidialCloserLog extends Model
{
	protected $connection = 'mysql2';
    protected  $table="vicidial_closer_log";
}
