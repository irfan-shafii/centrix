<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VicidialIngroup extends Model
{
	protected $connection = 'mysql2';
    protected  $table="vicidial_inbound_groups";
}
