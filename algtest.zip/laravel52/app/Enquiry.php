<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Enquiry extends Model
{
	protected $connection = 'mysql4';
    protected  $table="enquiry_categories";
}
