<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\VicidialLog;
use App\VicidialCloserLog;
use App\VicidialDialLog;
use App\VicidialList;
use App\VicidialLists;
use App\VicidialCampaign;
use App\VicidialAgentLog; 
use Illuminate\Support\Facades\Input; //header
use Excel;
use App\MKtargt;
use App\MKhisty;
use App\MKvlink;
use App\MKvehic;
use Carbon\Carbon;

class ReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function customerold($mobile,$user)
    {
        
        //$upscales = DB::table('vehicle_upscales')->get();

        $user_info = $user;
        $mobile_number = $mobile;
        $account = DB::table('account')->where('mobile_number',$mobile)->get();
        if(count($account)>0){
            $id_account = $account[0]->id_account;
            $fname = $account[0]->first_name;
            $lname = $account[0]->last_name;
            $mobile2 = $account[0]->alternate_mobile;
            $gender = $account[0]->gender;
            $civilid = $account[0]->civil_id;
            $address = $account[0]->address;
        }
        else{
            $id_account = 0;
            $fname = '';
            $lname = '';
            $mobile2 ='';
            $gender = '';
            $civilid = '';
            $address ='';

        }
        $question = DB::table('csi_questions')->join('csi_answers','csi_questions.id', '=','csi_answers.question_id')->select('csi_questions.*', 'csi_answers.answer', 'csi_answers.description')->where('csi_questions.parent_id','0')->get();

        $vehicles = DB::table('vehicles')->where('phone_number',$mobile_number)->get();
        if(count($vehicles) > 0){
        $upscales = DB::table('vehicles')->join('vehicle_upscales','vehicles.vehicle_brand', '=','vehicle_upscales.brand')->select('vehicle_upscales.*', 'vehicles.phone_number')->where('vehicles.phone_number',$mobile)->get();
        }
        else{
        $upscales = DB::table('vehicle_upscales')->get();
        }

        $enquiry_categories = DB::table('enquiry_categories')->where('parent_id','0')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories1 = DB::table('enquiry_categories')->where('parent_id','1')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories2 = DB::table('enquiry_categories')->where('parent_id','2')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories3 = DB::table('enquiry_categories')->where('parent_id','3')->orderBy('id_enquiry_category','asc')->get();
        $account_comments = DB::table('opportunity')->where('id_account',$id_account)->orderBy('id_opp','desc')->get();
        //print_r($upscales); exit();
        return view('customer_old',compact('upscales','account','account_comments','enquiry_categories','vehicles','sub_categories1','sub_categories2','sub_categories3','question','user_info','mobile_number','fname','lname','id_account','mobile','mobile2','gender','civilid','address'));
    }



    public function customeruser($mobile,$user,$listid=0,$campaignid=0,$ingroup=0,$cusid=0)
    {
        
        //print_r($cusid); exit();

        $user_info = $user;
        $mobile_number = $mobile;

        $mktargt = MKtargt::select('MAGIC','FIRSTNAM','SURNAME','PHONE002','PHONE004','ADDRESS','ADDRESS001','ADDRESS002','ADDRESS003','ADDRESS004')->where('PHONE004',$mobile)->get();

        if(count($mktargt) > 0){
            $cusid = $mktargt[0]->MAGIC;
        }

    $listnames = VicidialLists::select('list_name')->where('list_id',$listid)->get();
    $listname =  'ListName';
    if(count($listnames) > 0){
       $listname =  $listnames[0]->list_name;
    }

        // $mkvehic = MKvehic::select('MAGIC','REGNO','MODELVAR','MODEL','MILEAGE','MOTDATE','LASTSERV','LASTWORK')->join('mk_00_vlink','mk_00_vehic.MAGIC', '=','mk_00_vlink.VEHMAGIC')->addSelect('mk_00_vlink.CTMAGIC as ctmagic')->where('mk_00_vlink.CTMAGIC','231272')->get();


        // $vehhisty = MKhisty::select('date','code','details','miles','invno','wipno','prime','tarmagic','value','accno','company')->where('prime','421150')->where('tarmagic','231272')->get();
        // print_r($vehhisty); exit();

        $csi_questions = DB::table('csi_questions')->where('parent_id','0')->first();

        $account = DB::table('account')->where('mobile_number',$mobile)->get();
            $id_account = 0;
            $fname = '';
            $lname = '';
            $mobile2 ='';
            $gender = '';
            $civilid = '';
            $address ='';

        $upscales = DB::table('vehicle_upscales')->get();

        $enquiry_categories = DB::table('enquiry_categories')->where('parent_id','0')->orderBy('id_enquiry_category','asc')->get();

        return view('customer',compact('upscales','mktargt','account','user_info','enquiry_categories','mobile_number','fname','lname','id_account','mobile','mobile2','gender','civilid','address','csi_questions','listid','campaignid','ingroup','cusid','listname'));
    }



    public function customerregno($regno,$user,$listid=0,$campaignid=0,$ingroup=0,$cusid=0)
    {
        
        $ctmagic = 0;
        $phone = 0;
        //print_r($regno); exit();
        $registerno = str_replace("__","/",$regno);
        $vehicles = MKvehic::select('MAGIC','REGNO')->join('mk_00_vlink','mk_00_vehic.MAGIC', '=','mk_00_vlink.VEHMAGIC')->addSelect('mk_00_vlink.CTMAGIC as ctmagic')->where('mk_00_vehic.REGNO',$registerno)->get();

        if(count($vehicles) > 0){
        $ctmagic = $vehicles[0]->ctmagic;
        $customer = MKtargt::select('PHONE004')->where('MAGIC',$ctmagic)->get();
        if(count($customer) > 0){       
        $phone = $customer[0]->PHONE004;
        }

        } 
        //print_r($customer); exit();
        return redirect('/customer/'.$phone.'/'.$user.'/'.$listid.'/'.$campaignid.'/'.$ingroup);

    }

    public function history($session=0,$roof=0,$ref=0,$terminal=0)
    {
        $response = '0http://37.34.236.116:1180/alghanim/public/laravel_installation.txt';
        $url = explode("http://", $response);
        $responsecode = $url[0];
        $myfilename = "http://".$url[1];
        //print_r($url[1]); exit();
        return view('readfile',compact('myfilename'));

    }

    public function customer_new()
    {
       // echo $mobile;
        if (isset($_GET["mobile"]) && isset($_GET["user"])) {
            $mobile=$_GET["mobile"];
            $user=$_GET["user"];
        return redirect('/customer/'.$mobile.'/'.$user);
        }
        else if (isset($_GET["mobile"])) {
            $mobile=$_GET["mobile"];
        return redirect('/customer/'.$mobile);
        }// echo $mobile;

        $upscales = DB::table('vehicle_upscales')->get();
        $enquiry_categories = DB::table('enquiry_categories')->where('parent_id','0')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories1 = DB::table('enquiry_categories')->where('parent_id','1')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories2 = DB::table('enquiry_categories')->where('parent_id','2')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories3 = DB::table('enquiry_categories')->where('parent_id','3')->orderBy('id_enquiry_category','asc')->get();
        return view('customer',compact('upscales','enquiry_categories','sub_categories1','sub_categories2','sub_categories3'));
    }


    public function inquiries(Request $request)
    {
            $fromdate = date("Y-m-d");

        //print_r($fromdate); exit();
        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
            
        $inquiries = DB::table('opportunity')->whereBetween('date_add',[$fromdate, $todate1])->orderBy('date_add','desc')->get();
        //print_r($inquiries); exit();

        return view('inquiries',compact('inquiries','fromdate'));
    }

    public function appointments(Request $request)
    {
       // echo $mobile;

            $fromdate = date("Y-m-d");

        //print_r($mobiles); exit();
        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
            
        $appointments = DB::table('appointments')->whereBetween('appointment_date',[$fromdate, $todate1])->orderBy('id','desc')->get();
    

        return view('appointments',compact('appointments','fromdate'));
    }


    public function vuseranswers($id)
    {
       // echo $mobile;


        $answer = DB::table('csi_answers')->where('id',$id)->get();

        $questions = DB::table('csi_answers')->where('date_time',$answer[0]->date_time)->where('vehicle_id',$answer[0]->vehicle_id)->orderBy('id','asc')->get(); 
        $vehicles = MKvehic::select('MAGIC','REGNO','MODEL','MODELVAR')->where('MAGIC',$answer[0]->vehicle_id)->get();
        $vehdetails = '';
        if(count($vehicles) > 0){
            $vehdetails = $vehicles[0]->MODEL.' - '. $vehicles[0]->MODELVAR.' - '. $vehicles[0]->REGNO;
        }

        return view('viewanswers',compact('questions','vehdetails'));
    }

    public function useranswers(Request $request)
    {
            $phone = '';

            $fromdate = date("Y-m-d");

        //print_r($mobiles); exit();
        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));

        //print_r($mobiles); exit();
        if(!empty($request->phone) && empty($request->fromdate)){
            $phone = $request->phone;
            
        $mobiles = DB::table('csi_answers')->where('mobile_number',$phone)->select(DB::raw('count(*) as datecount, date_time'))->groupBy('date_time')->get();
        }
        elseif(!empty($request->phone) && !empty($request->fromdate)){
            $phone = $request->phone;
            
        $mobiles = DB::table('csi_answers')->where('mobile_number',$phone)->whereBetween('date_time',[$fromdate, $todate1])->select(DB::raw('count(*) as datecount, date_time'))->groupBy('date_time')->get();
        }
        elseif(empty($request->phone) && !empty($request->fromdate)){
            
        $mobiles = DB::table('csi_answers')->whereBetween('date_time',[$fromdate, $todate1])->select(DB::raw('count(*) as datecount, date_time'))->groupBy('date_time')->get();
        }
        else{
            
        $mobiles = DB::table('csi_answers')->select(DB::raw('count(*) as datecount, date_time'))->groupBy('date_time')->get();
        }
        //print_r($mobiles); exit();
        return view('useranswers',compact('mobiles','phone','fromdate'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function auto_dial()
    {
        $lists = VicidialLists::select('list_id','list_name','campaign_id')->get();
        //print_r($lists); exit();
        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->get();
        
        // print_r($inbounds); exit();
        return view('auto_dial',compact('lists','campaigns'));
    }

    public function upload(Request $request)
    {

        //print_r($request->all()); exit();
        $path = $request->file('import_file')->getRealPath();

        $data = Excel::load($path)->get();
        
        $headerRow = $data->first()->keys()->toArray();

        if($data->count()){

            $rec_count = 0;

            foreach ($data as $key => $value) {

                    //print_r($value->mobile);

            $lists = VicidialList::insert(['phone_number' => $value->mobile,'first_name' => $value->name,'list_id' => $request->listid,'entry_date' => date("Y-m-d H:i:s"),'status'=>'NEW','called_since_last_reset'=>'N']);

            $rec_count++;

               // print_r($data);
            }
            $alert = $rec_count." Records Added Successfully";
            //exit();
        }
        return redirect('/auto-dial')->with('alert', $alert);

    }


    public function auto_upload()
    {
        $lists = VicidialLists::select('list_id','list_name','campaign_id')->get();
        //print_r($lists); exit();
        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->get();
        

        $folder = DB::table('cron_folder')->where('delete_status','0')->first();
        
        // print_r($inbounds); exit();
        return view('autoupload_dial',compact('lists','campaigns','folder'));
    }

    public function autodial_folder(Request $request)
    {
        DB::table('cron_folder')->update(['delete_status' => '1']);
        DB::table('cron_folder')->insert(['location' => $request->directory]);
        return redirect('/autoupload-dial');
    }
    public function autodial_upload(Request $request)
    {

        //print_r($request->all()); exit();
        //$path = 'public/auto_dial/auto_dial.csv';


        $path = $request->file('import_file')->getRealPath();

        $data = Excel::load($path)->get();
        
        $headerRow = $data->first()->keys()->toArray();

        if($data->count()){

            $rec_count = 0;

            foreach ($data as $key => $value) {

                    //print_r($value->mobile);

            $lists = DB::table('cron_autodial')->insert(['phone_number' => $value->mobile,'first_name' => $value->name,'listid' => $request->listid,'campaignid' => $request->campaignid,'entry_datetime' => $request->entry_date]);

            $rec_count++;

                // /print_r($data);
            }
            $alert = $rec_count." Records Added Successfully";
            //exit();
        }

        $product_img = Input::file('import_file');
  
        //print_r($destinationPath1); exit();
        if($product_img)
         {
  
              $destinationPath1 = $_SERVER['DOCUMENT_ROOT'].'/alghanim/public/auto_dial';           
              $timestamp1 = str_replace([' ', ':'], '-', date("YmdHis"));
              $namefile1 = $product_img->getClientOriginalName();    
              $recfilename1 = preg_replace('/\s+/', '', $namefile1);
              $recfilename1 = $timestamp1."_123_".$recfilename1;
              $upload_success1 = Input::file('import_file')->move($destinationPath1, $recfilename1);
              $certificatePath1 = ('http://'.$_SERVER['HTTP_HOST']."/alghanim/public/auto_dial/".$recfilename1);

         }

        return redirect('/autoupload-dial')->with('alert', $alert);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //print_r($request->all()); exit();
        $id_account = $request->id_account;
        if($id_account == 0){
        $id_account= DB::table('account')->insertGetId(['first_name'=>$request->fname,'last_name'=>$request->lname,'mobile_number'=>$request->mobile,'alternate_mobile'=>$request->mobile2,'civil_id'=>$request->civilid,'id_user'=>$request->user_info,'gender'=>$request->gender,'address'=>$request->address,'date_add'=>date("Y-m-d H:i:s"),'date_update'=>date("Y-m-d H:i:s")]);
        }
        else{

        DB::table('account')->where('id_account',$id_account)->update(['first_name'=>$request->fname,'last_name'=>$request->lname,'mobile_number'=>$request->mobile,'alternate_mobile'=>$request->mobile2,'civil_id'=>$request->civilid,'id_user'=>$request->user_info,'gender'=>$request->gender,'address'=>$request->address,'date_update'=>date("Y-m-d H:i:s")]);
        }
        return redirect('/customer/'.$request->mobile.'/'.$request->user_info);
    }

    public function vehstore(Request $request)
    {
        //print_r($request->all()); exit();
        $id_account = $request->vehicle_id;

        if($id_account == 0){

        DB::table('vehicles')->insert(['phone_number'=>$request->phone_number,'id_account'=>$request->vehid_account,'vehicle_type'=>$request->vehicleinfo,'vehicle_model'=>$request->vehmodel,'vehicle_plate_no'=>$request->plateno,'color'=>$request->vehcolor,'vehicle_model_year'=>$request->vehyear,'dealer'=>$request->vehsalesman,'town'=>$request->vehshowroom]);
        }
        else{
        DB::table('vehicles')->where('id',$request->vehicle_id)->update(['phone_number'=>$request->phone_number,'id_account'=>$request->vehid_account,'vehicle_type'=>$request->vehicleinfo,'vehicle_model'=>$request->vehmodel,'vehicle_plate_no'=>$request->plateno,'color'=>$request->vehcolor,'vehicle_model_year'=>$request->vehyear,'dealer'=>$request->vehsalesman,'town'=>$request->vehshowroom]);

        }
        return redirect('/customer/'.$request->phone_number.'/'.$request->user_info.'/'.$request->listid.'/'.$request->campaignid.'/'.$request->ingroup);
    }


    public function enqstore(Request $request)
    {
        //print_r($request->all()); exit();
        $id_account = $request->enq_account;

        //$iduser = DB::table('account')->where('id_account',$id_account)->first();

        if(!empty($request->category)){
        $category = $request->category;
        $subcategory = '';

        $subcategory = "";
        $subcategory2 = "";
        $subcategory3 ="";

        if(!empty($request->subcategory1)){
        $subcategory = $request->subcategory1;
        }
        if(!empty($request->subcategory2)){
        $subcategory2 = $request->subcategory2;
        }
        if(!empty($request->subcategory3)){
        $subcategory3 = $request->subcategory3;
        }

        $appointment = $request->appointment;
        if(!empty($appointment)){
            $appointment_date = date("Y-m-d",strtotime($appointment));
            $appointment_time = date("H:i:s",strtotime($appointment));
        }
        else{
            $appointment_date = '';
            $appointment_time = '';
        }


        $opp_id = DB::table('opportunity')->insertGetId(['id_account'=>$id_account,'enquiry_category'=>$request->category,'enquiry_subcategory'=>$subcategory,'enquiry_subcategory2'=>$subcategory2,'enquiry_subcategory3'=>$subcategory3,'description'=>$request->description,'appointment_date'=>$appointment_date,'appointment_time'=>$appointment_time,'id_agent'=>$request->user_info,'first_name'=>$request->fname1,'last_name'=>$request->lname1,'mobile_number'=>$request->phone_number,'alternate_number'=>$request->mobile2,'date_add'=>date("Y-m-d H:i:s"),'date_update'=>date("Y-m-d H:i:s")]);


        if(!empty($appointment)){
            $interest = $request->interest;
            if($interest == 'Chevrolet'){
                $interest = $interest.' - '.$request->Chevrolet;                
            }
            if($interest == 'Cadillac'){
                $interest = $interest.' - '.$request->Cadillac;   
            }
            if($request->category == '1'){
            $appointmentcode = $request->appointmentcode1;                
            }
            if($request->category == '2'){
            $appointmentcode = $request->appointmentcode;                
            }
        DB::table('appointments')->insert(['id_account'=>$id_account,'mobile_number'=>$request->phone_number,'appointment_datetime'=>$request->appointment,'appointment_date'=>$appointment_date,'appointment_time'=>$appointment_time,'salesman'=>$request->salesman,'agentname'=>$request->agentname,'showroom'=>$request->showroom,'advisorname'=>$request->advisorname,'interest'=>$interest,'appointmenttype'=>$request->appointmenttype,'appointmentcode'=>$appointmentcode,'appbooked'=>$request->apptab,'opp_id'=>$opp_id]);
        }

        DB::table('account_comments')->insert(['id_account'=>$id_account,'description'=>$request->description,'date_add'=>date("Y-m-d H:i:s"),'date_update'=>date("Y-m-d H:i:s")]);
        }
        return redirect('/customer/'.$request->phone_number.'/'.$request->user_info.'/'.$request->listid.'/'.$request->campaignid.'/'.$request->ingroup);
    }



    public function index(Request $request)
    {
        $current_date = date('Y-m-d');
        //$current_date = '2019-11-17';
        $day = date('d');
        $month = date('m');
        $year = date('Y');
        $phone = '';

        $inbound_count = 0;
        $outbound_count = 0;
        $missed_count = 0;

        if(!empty($request->day)){
            $day = $request->day;
            $month = $request->month;
            $year = $request->year;
        }
            $fromdate = $year. '-' . $month. '-' . $day;
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
        $outbound = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->get();
        $inbound = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','!=','DROP')->get();
        $missed = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','=','DROP')->get();
        if(!empty($request->phone)){
            $phone = $request->phone;
            $inbound = $inbound->where('phone_number',$phone);
            $outbound = $outbound->where('phone_number',$phone);
            $missed = $missed->where('phone_number',$phone);
        }
        $inbound_count = $inbound->count();
        $outbound_count = $outbound->count();
        $missed_count = $missed->count();

        $vicidial_agent_log = VicidialAgentLog::join('vicidial_users', 'vicidial_agent_log.user', '=', 'vicidial_users.user')->whereBetween('event_time',[$fromdate, $todate1])->where('talk_sec','<','65000')->where('pause_sec','<','65000')->where('wait_sec','<','65000')->where('dispo_sec','<','65000')->where('status','!=',null);

        $top_agents = $vicidial_agent_log->select('vicidial_agent_log.user', DB::raw('count(*) as calls'))->addSelect('vicidial_users.full_name','vicidial_agent_log.user_group')->groupBy('vicidial_agent_log.user','vicidial_agent_log.user_group','vicidial_users.full_name')->orderBy('calls','desc')->skip(0)->take(5)->get();
        $agentcounts = VicidialAgentLog::select('user','event_time')->whereBetween('event_time',[$fromdate, $todate1])->where('status','!=',null)->count();

        $inbound_hourly = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','!=','DROP')->get();

        $hourlyrep = array();

        foreach ($inbound_hourly as $hour) {
            $timeopp = date("$year-$month-$day H:00:00",strtotime($hour->call_date));
            $hourlyrep[] = array(
                        "time" => $timeopp,
                        "category" =>$hour->enquiry_category
                        );


        }

        $hour8 = 0;
        $hour9 = 0;
        $hour10 = 0;
        $hour11 = 0;
        $hour12 = 0;
        $hour13 = 0;
        $hour14 = 0;
        $hour15 = 0;
        $hour16 = 0;
        $hour17 = 0;
        $hour18 = 0;
        $hour19 = 0;
        $hour20 = 0;


        $hourly = array();

        foreach ($hourlyrep as $hrrep) {
            if($hrrep['time'] == date("$year-$month-$day 08:00:00")){
                $hour8++;
            }
            if($hrrep['time'] == date("$year-$month-$day 09:00:00")){
                $hour9++;
            }
            if($hrrep['time'] == date("$year-$month-$day 10:00:00")){
                $hour10++;
            }
            if($hrrep['time'] == date("$year-$month-$day 11:00:00")){
                $hour11++;
            }
            if($hrrep['time'] == date("$year-$month-$day 12:00:00")){
                $hour12++;
            }
            if($hrrep['time'] == date("$year-$month-$day 13:00:00")){
                $hour13++;
            }
            if($hrrep['time'] == date("$year-$month-$day 14:00:00")){
                $hour14++;
            }
            if($hrrep['time'] == date("$year-$month-$day 15:00:00")){
                $hour15++;
            }
            if($hrrep['time'] == date("$year-$month-$day 16:00:00")){
                $hour16++;
            }
            if($hrrep['time'] == date("$year-$month-$day 17:00:00")){
                $hour17++;
            }
            if($hrrep['time'] == date("$year-$month-$day 18:00:00")){
                $hour18++;
            }
            if($hrrep['time'] == date("$year-$month-$day 19:00:00")){
                $hour19++;
            }
            if($hrrep['time'] == date("$year-$month-$day 20:00:00")){
                $hour20++;
            }
        }


            $hourly[] = array(
                        "hour" => 8,
                        "calls" =>$hour8,
                        );
            $hourly[] = array(
                        "hour" => 9,
                        "calls" =>$hour9
                        );
            $hourly[] = array(
                        "hour" => 10,
                        "calls" =>$hour10
                        );
            $hourly[] = array(
                        "hour" => 11,
                        "calls" =>$hour11
                        );
            $hourly[] = array(
                        "hour" => 12,
                        "calls" =>$hour12
                        );
            $hourly[] = array(
                        "hour" => 13,
                        "calls" =>$hour13
                        );
            $hourly[] = array(
                        "hour" => 14,
                        "calls" =>$hour14
                        );
            $hourly[] = array(
                        "hour" => 14,
                        "calls" =>$hour15
                        );

            $hourly[] = array(
                        "hour" => 16,
                        "calls" =>$hour16
                        );

            $hourly[] = array(
                        "hour" => 17,
                        "calls" =>$hour17
                        );

            $hourly[] = array(
                        "hour" => 18,
                        "calls" =>$hour18
                        );
            $hourly[] = array(
                        "hour" => 19,
                        "calls" =>$hour19
                        );
            $hourly[] = array(
                        "hour" => 20,
                        "calls" =>$hour20
                        );
        //Get all data for the day
        $enqrep1 = array();
        $enqrep2 = array();
        $enqrep3 = array();

        $sale = DB::table('opportunity')->select('date_add','enquiry_category')->whereBetween('date_add',[$fromdate, $todate1])->where('enquiry_category','1')->get();
        $service = DB::table('opportunity')->select('date_add','enquiry_category')->whereBetween('date_add',[$fromdate, $todate1])->where('enquiry_category','2')->get();
        $other = DB::table('opportunity')->select('date_add','enquiry_category')->whereBetween('date_add',[$fromdate, $todate1])->where('enquiry_category','3')->get();
        //print_r($service); exit();

        foreach ($sale as $sal) {
            $timeopp = date("$year-$month-$day H:00:00",strtotime($sal->date_add));
            $enqrep1[] = array(
                        "time" => $timeopp,
                        "category" =>$sal->enquiry_category
                        );


        }

        $hour8 = 0;
        $hour9 = 0;
        $hour10 = 0;
        $hour11 = 0;
        $hour12 = 0;
        $hour13 = 0;
        $hour14 = 0;
        $hour15 = 0;
        $hour16 = 0;
        $hour17 = 0;
        $hour18 = 0;
        $hour19 = 0;
        $hour20 = 0;


        $sales = array();

        foreach ($enqrep1 as $enq1) {
            if($enq1['time'] == date("$year-$month-$day 08:00:00")){
                $hour8++;
            }
            if($enq1['time'] == date("$year-$month-$day 09:00:00")){
                $hour9++;
            }
            if($enq1['time'] == date("$year-$month-$day 10:00:00")){
                $hour10++;
            }
            if($enq1['time'] == date("$year-$month-$day 11:00:00")){
                $hour11++;
            }
            if($enq1['time'] == date("$year-$month-$day 12:00:00")){
                $hour12++;
            }
            if($enq1['time'] == date("$year-$month-$day 13:00:00")){
                $hour13++;
            }
            if($enq1['time'] == date("$year-$month-$day 14:00:00")){
                $hour14++;
            }
            if($enq1['time'] == date("$year-$month-$day 15:00:00")){
                $hour15++;
            }
            if($enq1['time'] == date("$year-$month-$day 16:00:00")){
                $hour16++;
            }
            if($enq1['time'] == date("$year-$month-$day 17:00:00")){
                $hour16++;
            }
            if($enq1['time'] == date("$year-$month-$day 18:00:00")){
                $hour17++;
            }
        }


            $sales[] = array(
                        "hour" => 8,
                        "calls" =>$hour8,
                        );
            $sales[] = array(
                        "hour" => 9,
                        "calls" =>$hour9
                        );
            $sales[] = array(
                        "hour" => 10,
                        "calls" =>$hour10
                        );
            $sales[] = array(
                        "hour" => 11,
                        "calls" =>$hour11
                        );
            $sales[] = array(
                        "hour" => 12,
                        "calls" =>$hour12
                        );
            $sales[] = array(
                        "hour" => 13,
                        "calls" =>$hour13
                        );
            $sales[] = array(
                        "hour" => 14,
                        "calls" =>$hour14
                        );
            $sales[] = array(
                        "hour" => 14,
                        "calls" =>$hour15
                        );

            $sales[] = array(
                        "hour" => 16,
                        "calls" =>$hour16
                        );

            $sales[] = array(
                        "hour" => 17,
                        "calls" =>$hour17
                        );

            $sales[] = array(
                        "hour" => 18,
                        "calls" =>$hour18
                        );
            $sales[] = array(
                        "hour" => 19,
                        "calls" =>$hour19
                        );
            $sales[] = array(
                        "hour" => 20,
                        "calls" =>$hour20
                        );



        foreach ($service as $servic) {
            $timeopp = date("$year-$month-$day H:00:00",strtotime($servic->date_add));
            $enqrep2[] = array(
                        "time" => $timeopp,
                        "category" =>$servic->enquiry_category
                        );


        }




        $hour8 = 0;
        $hour9 = 0;
        $hour10 = 0;
        $hour11 = 0;
        $hour12 = 0;
        $hour13 = 0;
        $hour14 = 0;
        $hour15 = 0;
        $hour16 = 0;
        $hour17 = 0;
        $hour18 = 0;
        $hour19 = 0;
        $hour20 = 0;


        $service = array();

        foreach ($enqrep2 as $enq1) {
            if($enq1['time'] == date("$year-$month-$day 08:00:00")){
                $hour8++;
            }
            if($enq1['time'] == date("$year-$month-$day 09:00:00")){
                $hour9++;
            }
            if($enq1['time'] == date("$year-$month-$day 10:00:00")){
                $hour10++;
            }
            if($enq1['time'] == date("$year-$month-$day 11:00:00")){
                $hour11++;
            }
            if($enq1['time'] == date("$year-$month-$day 12:00:00")){
                $hour12++;
            }
            if($enq1['time'] == date("$year-$month-$day 13:00:00")){
                $hour13++;
            }
            if($enq1['time'] == date("$year-$month-$day 14:00:00")){
                $hour14++;
            }
            if($enq1['time'] == date("$year-$month-$day 15:00:00")){
                $hour15++;
            }
            if($enq1['time'] == date("$year-$month-$day 16:00:00")){
                $hour16++;
            }
            if($enq1['time'] == date("$year-$month-$day 17:00:00")){
                $hour16++;
            }
            if($enq1['time'] == date("$year-$month-$day 18:00:00")){
                $hour17++;
            }
        }


            $service[] = array(
                        "hour" => 8,
                        "calls" =>$hour8,
                        );
            $service[] = array(
                        "hour" => 9,
                        "calls" =>$hour9
                        );
            $service[] = array(
                        "hour" => 10,
                        "calls" =>$hour10
                        );
            $service[] = array(
                        "hour" => 11,
                        "calls" =>$hour11
                        );
            $service[] = array(
                        "hour" => 12,
                        "calls" =>$hour12
                        );
            $service[] = array(
                        "hour" => 13,
                        "calls" =>$hour13
                        );
            $service[] = array(
                        "hour" => 14,
                        "calls" =>$hour14
                        );
            $service[] = array(
                        "hour" => 14,
                        "calls" =>$hour15
                        );

            $service[] = array(
                        "hour" => 16,
                        "calls" =>$hour16
                        );

            $service[] = array(
                        "hour" => 17,
                        "calls" =>$hour17
                        );

            $service[] = array(
                        "hour" => 18,
                        "calls" =>$hour18
                        );
            $service[] = array(
                        "hour" => 19,
                        "calls" =>$hour19
                        );
            $service[] = array(
                        "hour" => 20,
                        "calls" =>$hour20
                        );








        foreach ($other as $oth) {
            $timeopp = date("$year-$month-$day H:00:00",strtotime($oth->date_add));
            $enqrep3[] = array(
                        "time" => $timeopp,
                        "category" =>$oth->enquiry_category
                        );


        }


        $hour8 = 0;
        $hour9 = 0;
        $hour10 = 0;
        $hour11 = 0;
        $hour12 = 0;
        $hour13 = 0;
        $hour14 = 0;
        $hour15 = 0;
        $hour16 = 0;
        $hour17 = 0;
        $hour18 = 0;
        $hour19 = 0;
        $hour20 = 0;


        $other = array();

        foreach ($enqrep3 as $enq1) {
            if($enq1['time'] == date("$year-$month-$day 08:00:00")){
                $hour8++;
            }
            if($enq1['time'] == date("$year-$month-$day 09:00:00")){
                $hour9++;
            }
            if($enq1['time'] == date("$year-$month-$day 10:00:00")){
                $hour10++;
            }
            if($enq1['time'] == date("$year-$month-$day 11:00:00")){
                $hour11++;
            }
            if($enq1['time'] == date("$year-$month-$day 12:00:00")){
                $hour12++;
            }
            if($enq1['time'] == date("$year-$month-$day 13:00:00")){
                $hour13++;
            }
            if($enq1['time'] == date("$year-$month-$day 14:00:00")){
                $hour14++;
            }
            if($enq1['time'] == date("$year-$month-$day 15:00:00")){
                $hour15++;
            }
            if($enq1['time'] == date("$year-$month-$day 16:00:00")){
                $hour16++;
            }
            if($enq1['time'] == date("$year-$month-$day 17:00:00")){
                $hour16++;
            }
            if($enq1['time'] == date("$year-$month-$day 18:00:00")){
                $hour17++;
            }
        }



            $other[] = array(
                        "hour" => 8,
                        "calls" =>$hour8,
                        );
            $other[] = array(
                        "hour" => 9,
                        "calls" =>$hour9
                        );
            $other[] = array(
                        "hour" => 10,
                        "calls" =>$hour10
                        );
            $other[] = array(
                        "hour" => 11,
                        "calls" =>$hour11
                        );
            $other[] = array(
                        "hour" => 12,
                        "calls" =>$hour12
                        );
            $other[] = array(
                        "hour" => 13,
                        "calls" =>$hour13
                        );
            $other[] = array(
                        "hour" => 14,
                        "calls" =>$hour14
                        );
            $other[] = array(
                        "hour" => 14,
                        "calls" =>$hour15
                        );

            $other[] = array(
                        "hour" => 16,
                        "calls" =>$hour16
                        );

            $other[] = array(
                        "hour" => 17,
                        "calls" =>$hour17
                        );

            $other[] = array(
                        "hour" => 18,
                        "calls" =>$hour18
                        );
            $other[] = array(
                        "hour" => 19,
                        "calls" =>$hour19
                        );
            $other[] = array(
                        "hour" => 20,
                        "calls" =>$hour20
                        );


        $salecount = DB::table('opportunity')->select('date_add','enquiry_category')->whereBetween('date_add',[$fromdate, $todate1])->where('enquiry_category','1')->count();
        $servicecount = DB::table('opportunity')->select('date_add','enquiry_category')->whereBetween('date_add',[$fromdate, $todate1])->where('enquiry_category','2')->count();
        $othercount = DB::table('opportunity')->select('date_add','enquiry_category')->whereBetween('date_add',[$fromdate, $todate1])->where('enquiry_category','3')->count();

        //print_r($dial_lists_na); exit();
        return view('dashboard',compact('inbound_count','outbound_count','missed_count','top_agents','agentcounts','year','month','day','sales','service','other','hourly','salecount','servicecount','othercount'));
    }




    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
