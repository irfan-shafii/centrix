<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
use App\VicidialList;
use App\VicidialLists;

class ListManagementReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //print_r($request->all()); exit();
        $list_id = '';
        $status = '';
        $campaignids = Session::get('campaignid');


        $listids = '';
        if(!empty($campaignids)){
            $lists = VicidialLists::select('list_id','list_name','campaign_id')->whereIn('campaign_id',explode(",", $campaignids))->get();
            if(count($lists) > 0) {
                foreach ($lists as $list) {
                    $listgrps[] = $list->list_id;
                }
            $listids = implode(",", $listgrps);
            }
        }

        $list_ids = VicidialLists::select('list_id','list_name','campaign_id');
        if(!empty($campaignids)){
            $list_ids = $list_ids->whereIn('list_id',explode(",", $listids));
        }
        $list_ids = $list_ids->orderBY('list_name','asc')->get();

        $statuses = VicidialList::select(DB::raw('count(*) as status_count, status'))->groupBy('status')->get();

        if(!empty($request->list_id) && !empty($request->status)){

            $status = implode(",", $request->status);
            $list_id = intval($request->list_id);

            if($request->resetstatus == '1'){
                if(!empty($campaignids)){
                VicidialList::whereIn('status',explode(",", $status))->where('list_id',$list_id)->whereIn('list_id',explode(",", $listids))->update(['status'=>'NEW','called_since_last_reset'=>'N']);
                }
                else{
                VicidialList::whereIn('status',explode(",", $status))->where('list_id',$list_id)->update(['status'=>'NEW','called_since_last_reset'=>'N']);

                }
            }
            if($request->clearstatus == '1'){
                if(!empty($campaignids)){
                VicidialList::whereIn('status',explode(",", $status))->where('list_id',$list_id)->whereIn('list_id',explode(",", $listids))->delete();
                    
                }
                else{
                VicidialList::whereIn('status',explode(",", $status))->where('list_id',$list_id)->delete();

                }
            }

            $dial_lists = VicidialList::where('list_id',$list_id)->whereIn('status',explode(",", $status));
            $dial_lists_count = VicidialList::where('list_id',$list_id)->whereIn('status',explode(",", $status));

        }
        elseif(!empty($request->list_id) && empty($request->status)){
            
            $list_id = intval($request->list_id);

            if($request->resetstatus == '1'){
                if(!empty($campaignids)){
                VicidialList::where('list_id',$list_id)->whereIn('list_id',explode(",", $listids))->update(['status'=>'NEW','called_since_last_reset'=>'N']);
                    
                }
                else{
                VicidialList::where('list_id',$list_id)->update(['status'=>'NEW','called_since_last_reset'=>'N']);

                }
            }
            
            if($request->clearstatus == '1'){
                if(!empty($campaignids)){
                VicidialList::where('list_id',$list_id)->whereIn('list_id',explode(",", $listids))->delete();                
                }
                else{
                VicidialList::where('list_id',$list_id)->delete();
                }
            }

            $dial_lists = VicidialList::where('list_id',$list_id);
            $dial_lists_count = VicidialList::where('list_id',$list_id);
        
        }
        elseif(empty($request->list_id) && !empty($request->status)){
            $status = implode(",", $request->status);

            if($request->resetstatus == '1'){
                if(!empty($campaignids)){
                VicidialList::whereIn('status',explode(",", $status))->whereIn('list_id',explode(",", $listids))->update(['called_since_last_reset'=>'N','status'=>'NEW']);             
                }
                else{
                VicidialList::whereIn('status',explode(",", $status))->update(['called_since_last_reset'=>'N','status'=>'NEW']);
                }
            }
            if($request->clearstatus == '1'){
                if(!empty($campaignids)){
                VicidialList::whereIn('status',explode(",", $status))->whereIn('list_id',explode(",", $listids))->delete();             
                }
                else{
                VicidialList::whereIn('status',explode(",", $status))->delete();
                }
            }
            $dial_lists = VicidialList::whereIn('status',explode(",", $status));
            $dial_lists_count = VicidialList::whereIn('status',explode(",", $status));
        
        
        }
        else{

            if($request->resetstatus == '1'){
                if(!empty($campaignids)){
                VicidialList::whereIn('list_id',explode(",", $listids))->update(['status'=>'NEW','called_since_last_reset'=>'N']);        
                }
                else{
                VicidialList::update(['status'=>'NEW','called_since_last_reset'=>'N']);
                }
            }
            if($request->clearstatus == '1'){
                if(!empty($campaignids)){
                VicidialList::whereIn('list_id',explode(",", $listids))->delete();            
                }
                else{
                VicidialList::delete();
                }
            //print_r("reset2"); exit();
            }
            
            $dial_lists = VicidialList::where('lead_id','>','0'); 

            $dial_lists_count = VicidialList::where('lead_id','>','0');  
        
        
              
        }
            if(!empty($campaignids)){
                $dial_lists = $dial_lists->whereIn('list_id',explode(",", $listids));
            }
            $dial_lists = $dial_lists->paginate(100);  
            //print_r($dial_lists); exit();

            if(!empty($campaignids)){
                $dial_lists_count = $dial_lists->whereIn('list_id',explode(",", $listids));
            }
            $dial_lists_count = $dial_lists_count->count();   
        //print_r($statuses); exit();
        return view('list.index',compact('dial_lists','fromdate','todate','phone','user','status','list_id','dial_lists_count','list_ids','statuses'));
    }

    public function resetid($userids)
    {
        $lead_ids = explode(",", $userids);
        foreach ($lead_ids as $lead) {
        VicidialList::where('list_id',$lead)->update(['status'=>'NEW','called_since_last_reset'=>'N']);
        }
        return redirect('/leads/list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
