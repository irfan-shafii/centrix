<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use DB;
use App\MKtargt80;
use App\MKhisty80;
use App\MKvlink80;
use App\MKvehic80;
use App\MKnewst80;
use App\Oppotunity;
use App\Enquiry;

class FordAjaxController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    

    public function customerinfo(Request $request){

    if($request->ajax()){

        if(isset($_POST['cusid']) && !empty($_POST['cusid'])) {


        $cusid = $_POST['cusid']; 

        $account = MKtargt80::select('MAGIC','FIRSTNAM','SURNAME','PHONE002','PHONE004','ADDRESS001','ADDRESS002','ADDRESS003','ADDRESS004','SOCIALID')->where('MAGIC',$cusid)->get();
        $id_account = 0;
        if(count($account)>0){
            $id_account = $account[0]->MAGIC;
            $fname = $account[0]->FIRSTNAM;
            $lname = $account[0]->SURNAME;
            $mobile2 = $account[0]->PHONE002;
            //$gender = $account[0]->SEX;
            $gender = '';
            $civilid = $account[0]->SOCIALID;
            $address = $account[0]->ADDRESS001.' '.$account[0]->ADDRESS002.' '.$account[0]->ADDRESS003.' '.$account[0]->ADDRESS004;
        }


        $divHtml = '';
        $divHtml1 = '';
        $divHtml2 = '';
        $divHtml3 = '';
        
        $vlinks = MKvlink80::where('CTMAGIC',$id_account)->get();
        if(count($vlinks) > 0){

        $vehicles = MKvehic80::select('MAGIC','REGNO','MODELVAR','MODEL','MILEAGE','MOTDATE')->join('mk_80_vlink','mk_80_vehic.MAGIC', '=','mk_80_vlink.VEHMAGIC')->addSelect('mk_80_vlink.CTMAGIC as ctmagic')->where('mk_80_vlink.CTMAGIC',$id_account)->get();

        if(count($vehicles)>0){
        foreach ($vehicles as $veh) {
          $divHtml .= '<li class="vcclist" id="vcclist'. $veh->MAGIC .'"><a href="#" onclick="vehicleinfo('. $veh->MAGIC .');"> <i class="fa fa-truck"></i>  ' . $veh->MODEL.' - '. $veh->MODELVAR.' - '. $veh->REGNO .'</a></li>';
          $divHtml1 .= '<li class="vcc1list" id="vcc1list'. $veh->MAGIC .'"><a href="#" onclick="vehicleinfo('. $veh->MAGIC .');"> <i class="fa fa-truck"></i>  ' . $veh->MODEL.' - '. $veh->MODELVAR.' - '. $veh->REGNO .'</a></li>';
          $divHtml2 .= '<li class="vcc2list" id="vcc2list'. $veh->MAGIC .'"><a href="#" onclick="vehicleinfo('. $veh->MAGIC .');"> <i class="fa fa-truck"></i>  ' . $veh->MODEL.' - '. $veh->MODELVAR.' - '. $veh->REGNO .'</a></li>';
          $divHtml3 .= '<li class="vcc3list" id="vcc3list'. $veh->MAGIC .'"><a href="#" onclick="vehicleinfo('. $veh->MAGIC .');"> <i class="fa fa-truck"></i>  ' . $veh->MODEL.' - '. $veh->MODELVAR.' - '. $veh->REGNO .'</a></li>';
        }
        }
        }

        //$vehicles = DB::table('vehicles')->where('id_account',$id_account)->get();

        $fromdate = date("Y-m-d");
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
        $account_comments = Oppotunity::where('id_account',$id_account)->orderBy('id_opp','desc')->get();


        $enqHTML = '';


        if(count($account_comments) > 0){
        foreach($account_comments as $comment){

            $enq_cat = Enquiry::where('id_enquiry_category',$comment->enquiry_category)->first();
            $enq_sub_cat = Enquiry::where('id_enquiry_category',$comment->enquiry_subcategory)->first();
            $enq_category = '';
            $enq_subcategory = '';
            $enq_subcategory2 = '';
            $enq_subcategory3 = '';

             if(!empty($comment->enquiry_subcategory2) || $comment->enquiry_subcategory2 != '0'){

             $enq_sub_cat2 = Enquiry::where('id_enquiry_category',$comment->enquiry_subcategory2)->first();

            if(count($enq_sub_cat2) > 0){
              $enq_subcategory2 = "<br>".$enq_sub_cat2->category_name;
            }

            }

            if(!empty($comment->enquiry_subcategory3) || $comment->enquiry_subcategory3 = '0'){

             $enq_sub_cat3 = Enquiry::where('id_enquiry_category',$comment->enquiry_subcategory3)->first();

            if(count($enq_sub_cat3) > 0){
              $enq_subcategory3 = "<br>".$enq_sub_cat3->category_name;
            }
             }
            if(count($enq_cat) > 0){
              $enq_category = $enq_cat->category_name;
            }
            if(count($enq_sub_cat) > 0){
              $enq_subcategory = $enq_sub_cat->category_name;
            }

          $enqHTML .='<tr>';
              $enqHTML .='<td>'.$comment->id_opp.'</td>';
              $enqHTML .='<td>'.$comment->id_agent.'</td>';
              $enqHTML .='<td>'.$comment->type_of_profession.'</td>';
              $enqHTML .='<td>'.$comment->date_add.'</td>';
              $enqHTML .='<td>'.$enq_category.'</td>';
              $enqHTML .='<td>'.$enq_subcategory.''.$enq_subcategory2.''.$enq_subcategory3.'</td>';
              $enqHTML .='<td>'.$comment->description.'</td>';
          $enqHTML .='</tr>';


        }
        }



        }
        echo json_encode(array("fname"=>$fname,"lname"=>$lname,"mobile2"=>$mobile2,"gender"=>$gender,"civilid"=>$civilid,"address"=>$address,"divHtml"=>$divHtml,"divHtml1"=>$divHtml1,"divHtml2"=>$divHtml2,"divHtml3"=>$divHtml3,"enqHTML"=>$enqHTML));
    }

    }
    

    public function vehicleinfo(Request $request)
    {
    if($request->ajax())
    {

        if(isset($_POST['vehid']) && !empty($_POST['vehid'])) {

        $vehid = $_POST['vehid']; 
        $cusid = $_POST['cusid']; 

        $newst = MKnewst80::select('VEHMAGIC','SELLLOCN','exec as EXEC001','INVDATE','REGN','DESC001','DELDATE','MODEL')->where('VEHMAGIC',$vehid)->get();

            $showroom = '';
            $salesman = '';
            $invoice = '';
            $regno = '';
            $description = '';
            $deldate = '';
            $availmodel = '';
        if(count($newst)>0){
            $showroom = $newst[0]->SELLLOCN;
            $salesman = $newst[0]->EXEC001;
            $invoice = $newst[0]->INVDATE;
            $regno = $newst[0]->REGN;
            $description = $newst[0]->DESC001;
            $deldate = $newst[0]->DELDATE;
            $availmodel = $newst[0]->MODEL;
        }

        $vehicle = MKvehic80::select('MAGIC','REGNO','MODELVAR','MODEL','MILEAGE','MOTDATE','NEXTSERV','COLOUR')->where('MAGIC',$vehid)->get();
        //$vehicle = DB::table('vehicles')->where('id',$vehid)->get();
        if(count($vehicle)>0){
            $vehicleinfo = $vehicle[0]->MODELVAR;
            $vehmodel = $vehicle[0]->MODEL;
            $vehyear = $vehicle[0]->MODELYR;
            $vehcolor = $vehicle[0]->COLOUR;
            $vehshowroom = $vehicle[0]->MODEL;
            $plateno = $vehicle[0]->REGNO;
            // $lastservice = $vehicle[0]->LASTSERV;
            $lastservice = '';
            $nextservice = $vehicle[0]->NEXTSERV;

            $MOTDATE = $vehicle[0]->NEXTSERV;
            $MILEAGE = $vehicle[0]->MILEAGE;
            //$LASTWORK = $vehicle[0]->LASTWORK;
            $LASTWORK = '';
        }
        else{

            $vehicleinfo = '';
            $vehmodel = '';
            $vehyear = '';
            $vehcolor = '';
            $vehshowroom = '';
            $plateno = '';
            $lastservice = '';
            $nextservice = '';

            $MOTDATE = '';
            $MILEAGE = '';
            $LASTWORK = '';
        }

        $vehhisty = MKhisty80::select('date','code','details','miles','invno','wipno','prime','tarmagic','value','accno','company','archive')->where('prime',$vehid)->where('tarmagic',$cusid)->get();


          $histyHTML ='';
        if(count($vehhisty) > 0){
          foreach ($vehhisty as $histy) {
            if(!empty($histy->archive)){
                $archive = $histy->archive;
            }
            else{
                $archive = 0;
            }
          $histyHTML .='<tr>';
              $histyHTML .='<td><a href="'.url('/history').'/'.$archive.'" target="_blank" class="btn btn-success btn-xs"> '.$histy->code.' </a></td>';
              $histyHTML .='<td>'.$histy->date.'</td>';
              $histyHTML .='<td>'.$histy->miles.'</td>';
              $histyHTML .='<td>'.$histy->details.'</td>';
              $histyHTML .='<td>'.$histy->wipno.'</td>';
              $histyHTML .='<td>'.$histy->accno.'</td>';
              $histyHTML .='<td>'.$histy->value.'</td>';
              $histyHTML .='<td>'.$histy->invno.'</td>';
              $histyHTML .='<td>'.$histy->company.'</td>';
          $histyHTML .='</tr>';
        }

        }



        

        }
        echo json_encode(array("vehicleinfo"=>$vehicleinfo,"vehmodel"=>$vehmodel,"vehyear"=>$vehyear,"vehshowroom"=>$vehshowroom,"vehcolor"=>$vehcolor,"plateno"=>$plateno,"lastservice"=>$lastservice,"nextservice"=>$nextservice,"MOTDATE"=>$MOTDATE,"MILEAGE"=>$MILEAGE,"LASTWORK"=>$LASTWORK,"histyHTML"=>$histyHTML,"showroom"=>$showroom,"salesman"=>$salesman,"invoice"=>$invoice,"regno"=>$regno,"description"=>$description,"deldate"=>$deldate,"availmodel"=>$availmodel));
    }

    }





    public function getcategory(Request $request)
    {
    if($request->ajax())
    {
            $nexttype = 0; 
            $divhtml = ''; 
            $subvalue = 0;
            $apptab = "";

        if(isset($_POST['idvalue']) && !empty($_POST['idvalue'])) {

            $categoryid = $_POST['idvalue'];

            $category = Enquiry::where('id_enquiry_category',$categoryid)->first();
            $categorytype = $category->category_type;
            $categoryname = $category->category_name;

            if($categorytype =='1'){
            $nexttype = 2 ; 
            $enquiry_categories = Enquiry::where('parent_id',$categoryid)->where('category_type',$nexttype)->orderBy('id_enquiry_category','asc')->get();

            }            
            else if($categorytype =='2'){

            $nexttype = 3 ; 
            $enquiry_categories = Enquiry::where('parent_id',$categoryid)->where('category_type',$nexttype)->orderBy('id_enquiry_category','asc')->get();

            if($categoryid =='4' || $categoryid =='5' || $categoryid =='8' || $categoryid =='112' || $categoryid =='113' || $categoryid =='114' || $categoryid =='115' || $categoryid =='116' || $categoryid =='117' || $categoryid =='127' || $categoryid =='128' || $categoryid =='129' || $categoryid =='130' || $categoryid =='131' || $categoryid =='132' || $categoryid =='133' || $categoryid =='134' || $categoryid =='135' || $categoryid =='136' || $categoryid =='137'){
              $apptab = 1;
            }
            else{
              $apptab = 0;
            }

            }           
            else if($categorytype =='3'){
            $nexttype = 4 ; 
            $enquiry_categories = Enquiry::where('parent_id',$categoryid)->where('category_type',$nexttype)->orderBy('id_enquiry_category','asc')->get();

            }  


            if($categorytype =='1' || $categorytype =='2' || $categorytype =='3'){
            $divhtml = ''; 
            if(count($enquiry_categories) > 0){

            //$divhtml .= '<select class="form-control" name="subcategory'.$categorytype.'" id="subcategory'.$nexttype.'" onChange="getcategory(this);" required="">'; 
            $divhtml.='<option value="">Select</option>'; 
            foreach ($enquiry_categories as $enquiries) {
                $divhtml.='<option value="'.$enquiries->id_enquiry_category.'">'.$enquiries->category_name.'</option>'; 
            }
            //$divhtml.='</select>';


            }

            if ($categoryid == '113') {

            $events = DB::table('events')->where('delete_status','0')->get();

            //$divhtml .= '<select class="form-control" name="subcategory3" id="subcategory3"  required="">'; 
            $divhtml.='<option value="">Select</option>'; 
            foreach ($events as $event) {
                $divhtml.='<option value="'.$event->name.'">'.$event->name.'</option>'; 
            }
            //$divhtml.='</select>';

            }

            else if ($categoryid == '114' || $categoryid == '132') {

            $campaigns = DB::table('campaigns')->where('delete_status','0')->get();

            //$divhtml .= '<select class="form-control" name="subcategory3" id="subcategory3" required="">'; 
            $divhtml.='<option value="">Select</option>'; 
            foreach ($campaigns as $event) {
                $divhtml.='<option value="'.$event->name.'">'.$event->name.'</option>'; 
            }
            //$divhtml.='</select>';

            }

            else if ($categoryid == '118' || $categoryid == '119' || $categoryid == '134') {

            //$divhtml .= '<select class="form-control" name="subcategory3" id="subcategory3" required="">'; 
                $divhtml.='<option value="146">Excel Manual</option>'; 
            //$divhtml.='</select>';

            }

            else if ($categoryid == '128' || $categoryid == '129' || $categoryid == '130' || $categoryid == '131' || $categoryid == '133' || $categoryid == '138' || $categoryid == '139') {
                
            //$divhtml .= '<select class="form-control" name="subcategory3" id="subcategory3" required="">'; 
                $divhtml.='<option value="147">Kerridge</option>'; 
            //$divhtml.='</select>';

            }

            }

        }
        echo json_encode(array("divhtml"=>$divhtml,"categorytype"=>$categorytype,"subvalue"=>$subvalue,'categoryname'=>$categoryname,"apptab"=>$apptab));
    }

    }



    public function getquestion(Request $request)
    {
    if($request->ajax())
    {
        if(isset($_POST['questionid']) && !empty($_POST['questionid'])) {

            $questionid = $_POST['questionid'];
            $question = $_POST['question'];
            $answer = $_POST['answer'];
            $description = $_POST['description'];
            $mobile = $_POST['mobile'];
            $user = $_POST['user'];
            $ctime = $_POST['ctime'];
            $id_account = $_POST['id_account'];
            $vehid = $_POST['vehid'];

            $vehbrand = $_POST['vehbrand'];
            $vehmodel = $_POST['vehmodel'];
            $dealer = $_POST['dealer'];
            $showroom = $_POST['showroom'];
            $year = $_POST['vehyear'];
            $userinfo = $_POST['userinfo'];
            $fullname = $_POST['fullname'];

            $vehicle_det = ["<BRAND>", "<MODEL>", "<DEALER>", "<TOWN>", "<YEAR>", "<DATE>", "<USER>", "<NAME>"];
            $vehicle_val   = [$vehbrand,$vehmodel,$dealer,$showroom,$year,$year,$userinfo,$fullname];


        DB::table('csi_answers')->insert(['question'=>$question,'question_id'=>$questionid,'answer'=>$answer,'description'=>$description,'mobile_number'=>$mobile,'userid'=>$user,'date_time'=>$ctime,'id_account'=>$id_account,'vehicle_id'=>$vehid]);

            $description="";
            $previous_content = "";
            $previous_content1 = "";
            $nxtques = "";
            $nxtques1 = "";
            $nxtquesid = "";
            $nextans = "";


            $questiondetails = DB::table('csi_questions')->where('listid',$user)->where('id',$questionid)->get();

            $questionparent = DB::table('csi_questions')->where('listid',$user)->where('id',$questiondetails[0]->child_id)->get();

            if(count($questionparent) > 0){
            $nxtques = $questionparent[0]->question;
            $nxtques1 = $questionparent[0]->in_arabic;
            $nxtquesid = $questionparent[0]->id;
            $anstype = $questionparent[0]->anstype;
            $anstypes = DB::table('csi_answertype')->select('answertype')->where('id',$anstype)->get();
            if(count($anstypes) > 0){
            $nextans = $anstypes[0]->answertype;
            }

            $nxtques = str_replace($vehicle_det, $vehicle_val, $nxtques);
            $nxtques1 = str_replace($vehicle_det, $vehicle_val, $nxtques1);
            }
            else{

            $questionchild = DB::table('csi_questions')->where('listid',$user)->where('parent_id',$questionid)->where('ansif', 'like', '%'.$answer.'%')->get();
            if(count($questionchild) > 0){
            $nxtques = $questionchild[0]->question;
            $nxtques1 = $questionchild[0]->in_arabic;
            $nxtquesid = $questionchild[0]->id;
            $anstype = $questionchild[0]->anstype;
            $anstypes = DB::table('csi_answertype')->select('answertype')->where('id',$anstype)->get();
            if(count($anstypes) > 0){
            $nextans = $anstypes[0]->answertype;
            }

            $nxtques = str_replace($vehicle_det, $vehicle_val, $nxtques);
            $nxtques1 = str_replace($vehicle_det, $vehicle_val, $nxtques1);
            }

            }

            if (in_array($nxtquesid, array(4, 5, 6, 19, 23, 24, 25, 34, 38, 39, 40, 48, 49, 50))){            
              $description='<textarea class="form-control" placeholder="Specify Description..." id="description"></textarea>'; 
            }
            else{               
              $description='<input type="hidden" id="description" value="">'; 
            }

            $prev_answers = DB::table('csi_answers')->where('mobile_number',$mobile)->where('vehicle_id',$vehid)->where('date_time',$ctime)->orderBy('id','asc')->get();

            foreach ($prev_answers as $prev) {      

            $prev_ques = DB::table('csi_questions')->where('listid',$user)->where('id',$prev->question_id)->get();
            $prevques1  = $prev_ques[0]->in_arabic;
            $prevques  = $prev_ques[0]->question;
            $prevquestion1 = str_replace($vehicle_det, $vehicle_val, $prevques1);
            $prevquestion = str_replace($vehicle_det, $vehicle_val, $prevques);
            $previous_content .= $prevquestion."<br><a class='btn btn-success btn-xs'>".$prev->answer."</a>";
            $previous_content1 .= $prevquestion1."<br><a class='btn btn-success btn-xs'>".$prev->answer."</a>";
            if(!empty($prev->description)){
            $previous_content .= "<br>".$prev->description;
            $previous_content1 .= "<br>".$prev->description;
            }
            $previous_content .= "<br>";
            $previous_content1 .= "<br>";

            }



          }
        echo json_encode(array("question"=>$nxtques,"question1"=>$nxtques1,"quesid"=>$nxtquesid,"answer"=>$nextans,"description"=>$description,"previous"=>$previous_content,"previous1"=>$previous_content1));
        }

    }


    public function getsalesman(Request $request)
    {
    if($request->ajax())
    {
            $showroom = "";
            $divhtml = "";
        if(isset($_POST['idval']) && !empty($_POST['idval'])) {

            $idval = $_POST['idval'];

            $showrooms = DB::table('showrooms')->where('id',$idval)->get();
            if (count($showrooms) > 0) {
               $showroom = $showrooms[0]->name;
            }

            $salesman = DB::table('salesmans')->where('showroom_id',$idval)->where('delete_status','0')->get();


            $divhtml.='<option value="">Select</option>'; 
            foreach ($salesman as $sales) {
                $divhtml.='<option value="'.$sales->name.'">'.$sales->name.'</option>'; 
            }


          }
        echo json_encode(array("showroom"=>$showroom,"divhtml"=>$divhtml));
        }

    }


    public function getadvisor(Request $request)
    {
    if($request->ajax())
    {
            $showroom = "";
            $divhtml = "";
        if(isset($_POST['idval']) && !empty($_POST['idval'])) {

            $idval = $_POST['idval'];

            $showrooms = DB::table('service_centers')->where('id',$idval)->get();
            if (count($showrooms) > 0) {
               $showroom = $showrooms[0]->name;
            }

            $salesman = DB::table('sale_advisors')->where('center_id',$idval)->where('delete_status','0')->get();


            $divhtml.='<option value="">Select</option>'; 
            foreach ($salesman as $sales) {
                $divhtml.='<option value="'.$sales->name.'">'.$sales->name.'</option>'; 
            }


          }
        echo json_encode(array("showroom"=>$showroom,"divhtml"=>$divhtml));
        }

    }


    public function getcsi(Request $request)
    {
    if($request->ajax())
    {
        if(isset($_POST['vehid']) && !empty($_POST['vehid'])) {

            $mobile = $_POST['mobile'];
            $user = $_POST['user'];
            $ctime = $_POST['ctime'];
            $id_account = $_POST['id_account'];
            $vehid = $_POST['vehid'];

            $vehbrand = $_POST['vehbrand'];
            $vehmodel = $_POST['vehmodel'];
            $dealer = $_POST['dealer'];
            $showroom = $_POST['showroom'];
            $year = $_POST['vehyear'];
            $userinfo = $_POST['userinfo'];
            $fullname = $_POST['fullname'];

            $vehicle_det = ["<BRAND>", "<MODEL>", "<DEALER>", "<TOWN>", "<YEAR>", "<DATE>", "<USER>", "<NAME>"];
            $vehicle_val   = [$vehbrand,$vehmodel,$dealer,$showroom,$year,$year,$userinfo,$fullname];


            $description="";
            $previous_content = "";
            $nxtques = "";
            $nxtquesid = "";
            $nextans = "";
            $nextans1 = "";


            $questiondetails = DB::table('csi_questions')->where('listid',$user)->where('parent_id','0')->get();

            if(count($questiondetails) > 0){
            $nxtques = $questiondetails[0]->question;
            $nxtques1 = $questiondetails[0]->in_arabic;
            $nxtquesid = $questiondetails[0]->id;
            $anstype = $questiondetails[0]->anstype;
            $anstypes = DB::table('csi_answertype')->select('answertype')->where('id',$anstype)->get();
            if(count($anstypes) > 0){
            $nextans = $anstypes[0]->answertype;
            }

            $nxtques = str_replace($vehicle_det, $vehicle_val, $nxtques);
            $nxtques1 = str_replace($vehicle_det, $vehicle_val, $nxtques1);
            }


            if(empty($description)){               
              $description='<input type="hidden" id="description" value="">'; 
            }

          }
        echo json_encode(array("question"=>$nxtques,"question1"=>$nxtques1,"quesid"=>$nxtquesid,"answer"=>$nextans,"description"=>$description,"previous"=>$previous_content));
        }

    }



    public function edit_csi(Request $request)
    {
    if($request->ajax())
    {
        if(isset($_POST['idval']) && !empty($_POST['idval'])) {

            $idval = $_POST['idval'];

            $year = '2020';

            $vehicle_det = ["<BRAND>", "<MODEL>", "<DEALER>", "<TOWN>", "<YEAR>", "<DATE>"];
            $vehicle_val   = [$year,$year,$year,$year,$year,$year];
            $description="";
            $nxtques = "";
            $nxtquesid = "";
            $nextans = "";


            $answers = DB::table('csi_answers')->where('id',$idval)->get();
            $questionid = $answers[0]->question_id;

            $questiondetails = DB::table('csi_questions')->where('id',$questionid)->get();

            if(count($questiondetails) > 0){
            $nxtques = $questiondetails[0]->question;
            $nxtquesid = $questiondetails[0]->id;
            $anstype = $questiondetails[0]->anstype;
            $anstypes = DB::table('csi_answertype')->select('answertype')->where('id',$anstype)->get();
            if(count($anstypes) > 0){
            $nextans = $anstypes[0]->answertype;
            }

            $nxtques = str_replace($vehicle_det, $vehicle_val, $nxtques);
            }


            if(empty($description)){               
              $description='<input type="hidden" id="description" value="">'; 
            }

          }
        echo json_encode(array("question"=>$nxtques,"quesid"=>$nxtquesid,"answer"=>$nextans,"description"=>$description));
        }

    }


    public function gettxtdocument(Request $request)
    {
    if($request->ajax())
    {
        if(isset($_POST['newURL']) && !empty($_POST['newURL'])) {

            $txtdoc = $_POST['newURL'];

          }
        echo json_encode(array("txtdoc"=>$txtdoc));
        }

    }




    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
