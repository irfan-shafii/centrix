<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MKnewst extends Model
{
	//protected $connection = 'mysql3';
    protected  $table="vs_00_newst";
}
